package com.example.agenda_contactos.data

data class Contacto(
 var nombre:String, var telefono: String
)
