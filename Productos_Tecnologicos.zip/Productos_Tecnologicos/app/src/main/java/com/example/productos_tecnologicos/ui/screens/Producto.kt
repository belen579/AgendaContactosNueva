package com.example.productos_tecnologicos.ui.screens

data class Producto(
    val nombre: String,
    val precio: Double,
    var seleccionado: Boolean = false,

    var imagen: Int

)





