package com.example.productos_tecnologicos.ui.navigation

sealed class Screens(val route: String) {


    object inicio: Screens("Portada")
    object presupuesto : Screens ("Presupuesto")


    object confirmacion: Screens("Confirmacion")

}