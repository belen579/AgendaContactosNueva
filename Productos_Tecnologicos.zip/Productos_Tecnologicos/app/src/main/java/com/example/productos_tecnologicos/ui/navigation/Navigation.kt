package com.example.productos_tecnologicos.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.input.key.Key.Companion.Menu
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.compra_productos_tecnologicos.ui.Screens.previewcomposable
import com.example.productos_tecnologicos.ui.screens.ViewModel_Producto
import com.example.productos_tecnologicos.ui.screens.portadaviewModel

import com.example.productos_tecnologicos.ui.screens.total

@Composable
fun Navigation(){

    val navController = rememberNavController()
   val viewmodel =  (ViewModel_Producto())
    NavHost(navController, startDestination = Screens.inicio.route){
        composable(route=Screens.inicio.route){ portadaviewModel(viewmodel,navController = navController) }
        composable(route= Screens.presupuesto.route){
            previewcomposable(viewmodel, navController) //Nombre de la funcion a ejecutar
        }

        composable(route= Screens.confirmacion.route){
            total(viewmodel) //Nombre de la funcion a ejecutar
        }

    }


}


