package com.example.productos_tecnologicos.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.productos_tecnologicos.ui.navigation.Screens


@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable()
fun total(viewmodelProducto: ViewModel_Producto) {

    val scrollState = rememberLazyListState()
    var scaffoldBackgroundColor by remember { mutableStateOf(Color.Blue) }

    var Show by remember {
        mutableStateOf(false)
    }

    val context = LocalContext.current

    val toast = Toast.makeText(context, "Compra realizada con éxito", Toast.LENGTH_SHORT)
    val toast2 = Toast.makeText(context, "Compra cancelada", Toast.LENGTH_SHORT)



    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary),
                title = { Text(text = "Confirmación") },
                actions = {
                    IconButton(onClick = { viewmodelProducto.total }) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.Black)
                    }
                }
            )
        },
        contentColor = scaffoldBackgroundColor
    ) {
        Column(
            modifier = Modifier.padding(top = 100.dp)
        ) {
            Text(
                text = "Total: ${viewmodelProducto.gettotal()}€",
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Button(
                onClick = { Show= true
                },
                colors = ButtonDefaults.buttonColors(Color(103, 58, 183, 255)),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(text = "Confirmacion Compra")
                MyDialog(show = Show, onDismiss = {toast2.show()
                    Show= false}, onConfirm = {toast.show()
                    Show= false})
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 8.dp),
                state = scrollState
            ) {
                items(viewmodelProducto.listaproductoseleccionado) { producto ->
                    cardproducto(producto, viewmodelProducto)
                }
            }
        }

        Spacer(modifier = Modifier.height(80.dp))



    }
}




@Composable()
fun cardproducto(producto: Producto, viewmodelProducto: ViewModel_Producto) {


    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),


        ) {


        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {


            Text(
                text = "${producto.nombre}€ - ${producto.precio}",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(30.dp))


            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxHeight()
            ) {
                Image(
                    painter = painterResource(id = producto.imagen), // Reemplaza "imagen_producto" con el ID de tu imagen
                    contentDescription = null, // Descripción opcional para accesibilidad
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                )

            }

        }
    }
}












