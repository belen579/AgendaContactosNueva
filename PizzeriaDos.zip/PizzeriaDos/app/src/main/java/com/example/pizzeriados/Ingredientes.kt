package com.example.pizzeriados

import android.content.Context
import java.io.Serializable

enum class Ingredientes: Serializable {

   Pepino,
   Mozarella,
    Atun,
  Piña,
  Aceitunas,
    Champiñones,
    Mushrooms,
    Cucumber,
    Tuna,
    Pineapple,
    Olives,



}